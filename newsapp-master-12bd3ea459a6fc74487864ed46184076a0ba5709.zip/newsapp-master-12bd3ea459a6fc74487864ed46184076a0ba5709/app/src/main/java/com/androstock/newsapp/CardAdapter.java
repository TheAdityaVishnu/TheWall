package com.androstock.newsapp;

/**
 * Created by xxm on 15/03/18.
 */

public class CardAdapter {
}
